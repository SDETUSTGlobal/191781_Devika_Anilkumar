package com.example.demo_rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoRestController {
  public DemoRestController()
  {
	  System.out.println("Constructor demo");
	  }
  @GetMapping("/abc")	
  String met() {
	  System.out.println("jjjjjjjjjj");
	  return " Hello World";
  }
  @GetMapping("/ticket")
  Ticket getuser(@RequestParam("tid") int ticketid)
  {
	  return new Ticket(ticketid,"some user","some addr",3);
  }
  @PostMapping("/book")
  Ticket bookticket(@RequestBody Ticket ticket)
	 { 
		 System.out.println("Booking Ticket:"+ ticket);
		 ticket.setId(100);
		 return ticket;
	 }
  
}
